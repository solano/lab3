from matplotlib import pyplot as plt
import numpy as np
from scipy import optimize
from IPython.display import display, Math, Latex

#Resistividade : 2.92e−8
#

def linear(x,a,b): return a*x+b
def grafico():
    data1, data2, data3 = [np.loadtxt("data/aluminio_{}.dat".format(i)).T for i in range(1,4)]
    params1, params_convariance1 = optimize.curve_fit(linear, data1[0][::-1], data1[1])
    params2, params_convariance1 = optimize.curve_fit(linear, data2[0][::-1], data2[1])
    params3, params_convariance1 = optimize.curve_fit(linear, data3[0][::-1], data3[1])
    x = np.concatenate([data1[0],data2[0],data3[0]])
    x = x[::-1]
    y = np.concatenate([data1[1],data2[1],data3[1]])
    plt.figure(dpi=100)
    plt.scatter(x,y)
    x1 = x[0:data1[::-1][0].argmax()+1]
    x2 = x[data1[::-1][0].argmax()+1:data1[::-1][0].argmax()+data2[::-1][0].argmax()+2]
    x3 = x[data1[::-1][0].argmax()+data2[::-1][0].argmax()+2:data1[::-1][0].argmax()+data2[::-1][0].argmax()+data3[::-1][0].argmax()+3]
    ddp =  np.concatenate([linear(x1, params1[0], params1[1]), linear(x2, params2[0], params2[1]),linear(x3, params3[0], params3[1])])
    #plt.figure(dpi=100)
    #plt.ticklabel_format(style='sci',axis='y',scilimits=(0,0))
    #plt.scatter(x,y)
    #plt.plot(x,ddp)
    plt.title("Análise do alumínio")
    plt.xlabel('Distancia (m)')
    plt.ylabel('Diferença de potencial (V)')
    plt.axis([x[0],x[-1],y[0],y[-1]])
    display(Math(r'E=-\dfrac{\mathrm{d}V}{\mathrm{d}x}'))
    print("E1 = {}\nE2 = {}\nE3 = {}".format(-params1[0], -params2[0], -params3[0]))


grafico()
