from matplotlib import pyplot as plt
import numpy as np
from scipy import optimize
from IPython.display import display, Math, Latex
e = 1.6021765e-19                           # Carga fundamental
kb = 1.346e-23                              # Constante de boltzmann
e/kb                                        # 'k' da equação de Shockley
h = 6.62607004e-34                          # Constante de Planck
la = np.linspace(450e-9, 495e-9,50)         # Comprimento de onda luz azul (466)
lv = np.linspace(495e-9, 570e-9,50)         # Comprimento de onda luz verde (575)
c = 299792458                               # Velocidade da luz

T = 295                                     # Temperatura ambiente

R = 47.4
def planck(V,l): return V*e*l/c
def i_shockley(x,i0,k):return x*i0*(np.exp(k*x/T)-1)/(x+R*i0*(np.exp(k*x/T)-1))

def grafico(n,R):
    plt.figure(dpi=100)
    data = np.loadtxt('data/{}.dat'.format(n)).T
    params, params_covariance = optimize.curve_fit(i_shockley, data[0], data[1], p0=[1e-6,5000])
    plt.ticklabel_format(style='sci',axis='y',scilimits=(0,0))
    plt.scatter(data[0], data[1])
    #plt.plot(data[0], i_shockley(data[0], params[0], params[1]))
    plt.title("Análise de {}.dat".format(n))
    plt.xlabel('Tensão aplicada (V)')
    plt.ylabel('Corrente (A)')
    plt.axis([0,data[0][-1],0,data[1][-1]])
    display(Math(r'I = \dfrac{UI_0(\mathrm{e}^{kU/T}-1)}{U+RI_0(\mathrm{e}^{kU/T}-1)}'))
    eta = e/kb/params[1]
    #print("\ni0 = {}\nk = {}\nfator eta = {}".format(params[0], params[1], eta))


grafico("led_2",47.4)
