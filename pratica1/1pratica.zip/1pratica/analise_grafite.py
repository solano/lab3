import numpy as np

data = np.loadtxt("data/grafite.dat").T
# Média e desvio padrão em Mega Ohm
################################
# Resistencia = 6.1 Ohms
# Diametros = 2.47 mm +-(0.01mm)
# Comprimento = 5.70 cm +-(0.01cm)
###############################
np.median(data)/1e6
data.std()/1e6
