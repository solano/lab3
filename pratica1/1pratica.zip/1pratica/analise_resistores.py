from matplotlib import pyplot as plt
import numpy as np
from scipy import optimize
from IPython.display import display, Math, Latex

#47 nom == 47.4
#100 nom == 109.1
#100 nom == 98.0

def i_ohm(x,a,k):return x**k/R+a  # i = u/r
def grafico(n, R):
    plt.figure(dpi=100)
    data = np.loadtxt('data/{}.dat'.format(n)).T
    params, params_covariance = optimize.curve_fit(i_ohm, data[0], data[1], p0=[0,1])
    plt.ticklabel_format(style='sci',axis='y',scilimits=(0,0))
    plt.scatter(data[0], data[1])
    #plt.plot(data[0], i_ohm(data[0], params[0], params[1]))
    plt.xlabel('Tensão aplicada (V)')
    plt.ylabel('Corrente (A)')
    plt.title("Análise de {}.dat".format(n))
    plt.axis([0,data[0][-1],0,data[1][-1]])
    display(Math(r'I = \dfrac{U^k}{R}+a'))
    print("\na = {}\nk = {}".format(params[0], params[1]))

grafico("associacao_3",100.4)  # arquivo / resistencia
